

$(document).ready(function () {
    $("#grid").kendoGrid({
  
      dataSource: {
        type: "json",
        data: hierarchicalData,
        pageSize: 6,
        serverPaging: false,
        serverSorting: false,
        groupable: false,
      },
      height: 540,
      sortable: true,
      pageable: true,
      detailInit: detailInitCustomers,
      // dataBound: function () {
      //   this.expandRow(this.tbody.find("tr.k-master-row").first());
      // },
      columns: [
        {
          field: "threadtitle",
          title: "Thread Title",
          template: function (dataItem) {
            return dataItem.threadtitle;
          }
        },
        {
          field: "author",
          title: "Author",
          template: function (dataItem) {
            return dataItem.author;
          }
        },
        {
          field: "source",
          title: "Source",
          template: function (dataItem) {
            return dataItem.author;
          }
        },
        {
          field: "repiles",
          title: "Replies",
          template: function (dataItem) {
            return dataItem.source;
          }
        },
        {
          field: "createdat",
          title: "Created At",
          template: function (dataItem) {
            return dataItem.createdat;
          }
        },
        {
          field: "status",
          title: "Status",
          template: function (dataItem) {
            return dataItem.status;
          }
        }
      ],
  
    });
  
  
    // DATA FOR TAG
    var dataSource = new kendo.data.DataSource({
      data: [
        { Id: 1, tag: "book" },
        { Id: 2, tag: "india" },
        { Id: 3, tag: "sample" },
        { Id: 4, tag: "newindia" },
        { Id: 5, tag: "books" },
  
      ],
      sort: { field: "tag", dir: "asc" }
    });
  
    // DATA FOR category
    var categorysecData = [
  
      { text: "General", value: "G" },
      { text: "Staff", value: "S" },
      { text: "Site Feedback", value: "SF" }
  
    ];
    // DATA FOR STATS
    var statusData = [
  
      { text: "Open", value: "O" },
      { text: "Closed", value: "C" },
      { text: "Reopened", value: "RO" },
      { text: "Archived", value: "A" }
  
    ];
    // DATA FOR SOURCE
    var soruceboxData = [
      { text: "Select One", value: "0" },
      { text: "Case", value: "C" },
      { text: "Record Folder", value: "F" },
      { text: "Correspondence", value: "CP" },
      { text: "Direct", value: "D" }
  
    ];
  
    // Initialize Kendo DropDownList for tag
    $("#multiselecttag").kendoMultiSelect({
      dataTextField: "tag",
      dataValueField: "Id",
      dataSource: dataSource,
      filter: "contains",
      placeholder: "Please select Tag",
      downArrow: true,
      noDataTemplate: $("#noDataTemplate").html(),
  
    });
    // Initialize Kendo DropDownList for Soruce
    $("#sorucebox").kendoDropDownList({
      dataTextField: "text",
      dataValueField: "value",
      dataSource: soruceboxData
    });
  
    // Initialize Kendo DropDownList for Category
    $("#categoryDropDown2").kendoDropDownList({
      dataTextField: "text",
      dataValueField: "value",
      dataSource: categorysecData
    });
  
    // Initialize Kendo DropDownList for status
    $("#status").kendoDropDownList({
      dataTextField: "text",
      dataValueField: "value",
      dataSource: statusData
    });
    // Initialize Kendo DropDownList for date
    $("#datepicker").kendoDatePicker({
      dateInput: true
    });
    $("#datepickertodate").kendoDatePicker({
      dateInput: true
    });
    // Initialize Kendo DropDownList for person
    $("#perdontag").kendoMultiSelect({
      autoClose: false
    });
  
  
  });
  
  
  
  // Initialize Kendo  add new tag 
  function addNew(widgetId, value) {
    var widget = $("#" + widgetId).getKendoMultiSelect();
    var dataSource = widget.dataSource;
    console.log(dataSource.length)
    dataSource.add({
      Id: dataSource.data().length + 1,
      tag: value
    });
  
    var currentValue = widget.value();
    currentValue.push(dataSource.data().length)
    widget.value(currentValue);
    widget.trigger("change");
  
  
  
  };
  // TABLE SCRIPT
  // function detailInit(e) {
  //     $("<div/>").appendTo(e.detailCell).kendoGrid({
  
  //       dataSource: {
  //         type: "json",
  //           data: customerData,
  //         serverPaging: false,
  //         serverSorting: false,
  //         serverFiltering: false,
  //         pageSize: 10,
  //         // filter: { field: "EmployeeID", operator: "eq", value: e.data.EmployeeID }
  //       },
  //       detailInit: detailInitCustomers,
  //       scrollable: false,
  //       sortable: true,
  //       pageable: true,
  //       columns: [
  //         { field: "user", title:"User Name", },
  //         { field: "userid", title:"User ID",  },
  //         { field: "country", title:"country" },
  
  //       ],
  
  //     });
  //   }
  
  function detailInitCustomers(e) {
    $("<div/>").appendTo(e.detailCell).kendoGrid({
      dataSource: [
        {
          datas: "Participants",
          Identify: [
            {
              "UserName": " Mohamad",
              "Role": "	Moderator",
              "Added on ": "18-Jan-24"
            },
            {
              "UserName": " Aryan",
              "Role": "	Owner",
              "Added on ": "15-Jan-24"
            },
          ]
        },
        {
          datas: "Replies",
          Identify: [
            {
              "Reply": "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
              "User": "Aaisha",
              "Replied On": "13-Jan-24"
            },
            {
              "Reply": "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged",
              "User": "Samir",
              "Replied On": "13-Jan-24"
            }
          ]
        },
        {
          datas: "Documents",
          Identify: [
            {
              "User": "Aafrin",
              "Role":"Owner",
              "Document Name": "Forum",
            "Document Type":"PDF",
            "Document":"www.linkforum.com"
            },
            {
              "User": "Nazeem",
              "Role":"Moderator",
              "Document Name": "SSL",
            "Document Type":"PDF",
            "Document":"https:forum.com"
             
            }
          ]
        },
        {
          datas: "Audit Logs",
          Identify: [
            {
              "User": "Aafrin ",
              "Role": "Owner",
              "Edited Date": "18-Jan-24",
              "Actual ReplyDate": "14-Jan-24",
              "Replies": "Lorem Ipsum is simply dummy text of the printing and typesetting industry"
            },
            {
              "User": "Nazeem",
              "Role": "Participator",
              "Edited Date": "7-Jan-24",
              "Actual ReplyDate": "14-Jan-24",
              "Replies": "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged"
            }
          ]
        },
    
       
      ],
  
  
  
  
  
      detailTemplate: ' <div class="grid"></div>',
  
      detailInit: function (e) {
        e.detailRow.find(".grid").kendoGrid({
          dataSource: e.data.Identify
        });
      },
      columns: [
     
        {
          field: "datas", title: "Datas ",
  
        },
  
  
      ],
  
    });
  }
  
  
  
  
  var hierarchicalData = [
    {
      "threadtitle": "Sample thread Lorem ipsum text  ",
      "author": "Ammer",
      "repiles": "25",
      "source": "Case",
      "createdat": "24 Mar 2023, 6:45 pm",
      "status": "Closed",
  
    },
    {
      "threadtitle": "Welcome to your 14 day basic hosting trial!",
      "author": "Yousuf",
      "source": "Correspondence",
      "repiles": "25",
      "createdat": "25 Jun 2023, 9:00 am",
      "status": "Archived"
    },
    {
      "threadtitle": "What’s the best book you’ve ever read?",
      "author": "Imran",
      "source": "Case",
      "repiles": "1",
      "createdat": "2 Oct 2023, 10:45 pm",
      "status": "Open"
    },
    {
      "threadtitle": "Title of the topic",
      "author": "Abdullah",
      "source": "Direct",
      "repiles": "15",
      "createdat": "4 Jan 2024, 11:05 am",
      "status": "Reopened"
    },
  
  
  ];
  // var customerData = [
  //   {
  //     "user": "Aseem",
  //     "userid": "4125",
  //     "country": "Oman",
  
  
  //   },
  //   {
  //     "user": "Muhammad",
  //     "userid": "2536",
  //     "country": "Oman",
  
  //   },
  //   {
  //     "user": "Ishaaq",
  //     "userid": "745",
  //     "country": "Oman",
  
  //   },
  //   {
  //     "user": "Zakariya",
  //     "userid": "4586",
  //     "country": "Wadi Shab",
  //   },
  
  
  // ];
  
  // var repilesData = [
  //   {
  //     "datas": "Username",
  
  
  
  
  //   },
  //   {
  //     "userreply": "Muhammad",
  //     "replies": "Rohinton Mistry - A Fine Balance, Such a Long Journey",
  //     "replieon": "4 Jan 2024, 1:05 pm"
  
  
  //   },
  //   {
  //     "userreply": "Ishaaq",
  //     "replies": "Vikram Seth- A Suitable Boy, Two Lives",
  //     "replieon": "4 Jan 2024, 3:15 pm"
  
  //   },
  //   {
  //     "userreply": "Zakariya",
  //     "replies": "Lorem ipsum reply text text",
  //     "replieon": "4 Jan 2024, 11:05 pm"
  //   },
  
  
  // ];
  // Fileter
  
  
  
  function showFilter() {
    $(".filterRow").slideToggle('slow');
    $(this).toggleClass('showFilter');
    $("#filter").toggleClass('filterColor');
  }
  
  