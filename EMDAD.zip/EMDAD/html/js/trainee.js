var barChartData = {
    labels: [
      "2016",
      "2017",
      "2018",
      "2019",
      "2020",
      "2021",
      "2022",
      "2023"
    ],
    datasets: [
      {
        label: "Aaron",
        backgroundColor: "#ffcb05",
        borderColor: "#ffcb05",
        borderWidth: 1,
        data: [3, 5, 6, 8, 10, 11, 13, 15]
      },
      {
        label: "Abbas",
        backgroundColor: "#ed1b24",
        borderColor: "#ed1b24",
        borderWidth: 1,
        data: [2, 4, 6, 8, 11,13,15,17]
      },
      {
        label: "Abdul",
        backgroundColor: "#05A650",
        borderColor: "#05A650",
        borderWidth: 1,
        data: [3,5,7,9,11,13,17,19]
      },
    ]
  };
  
  var chartOptions = {
    responsive: true,
    legend: {
      position: "top"
    },
    title: {
      display: true,
      text: "Chart.js Bar Chart"
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
  
  window.onload = function() {
    var ctx = document.getElementById("canvas").getContext("2d");
    window.myBar = new Chart(ctx, {
      type: "bar",
      data: barChartData,
      options: chartOptions
    });
  };
  

  var ctx = document.getElementById('myChart').getContext('2d');
var chart = new Chart(ctx, {
	// The type of chart we want to create
	type: 'line', // also try bar or other graph types

	// The data for our dataset
	data: {
		labels: ["2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024"],
		// Information about the dataset
    datasets: [{
			label: "Employed",
			backgroundColor: '#05A650',
			borderColor: '#05a650',
			data: [25,40,50,55,65,82,88,92,100],
		}]
	},

	// Configuration options
	options: {
    layout: {
      padding: 10,
    },
		legend: {
			position: 'bottom',
		},
		title: {
			display: true,
			text: 'Precipitation in Toronto'
		},
		scales: {
			yAxes: [{
				scaleLabel: {
					display: true,
					labelString: 'Precipitation in mm'
				}
			}],
			xAxes: [{
				scaleLabel: {
					display: true,
					labelString: 'Month of the Year'
				}
			}]
		}
	}
});
var ctx = document.getElementById("barChart").getContext('2d');
var barChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ["2016", "2017", "2018", "2019", "2020", "2021", "2022","2023"],
    datasets: [{
      label: 'Batch',
      data: [20,30, 40,50,60,70,80,90],
      backgroundColor: "#ffcb05"
    },
  ]
  }
});


var ctx = document.getElementById('myLine').getContext("2d");

var myLine = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL","JUL","AUG","SEP","OCT","NOV","DEC"],
        datasets: [{
            label: "Skills",
            borderColor: "#ed1b24",
            pointBorderColor: "#ed1b24",
            pointBackgroundColor: "#ed1b24",
            pointHoverBackgroundColor: "#ed1b24",
            pointHoverBorderColor: "#ed1b24",
            pointBorderWidth: 8,
            pointHoverRadius: 5,
            pointHoverBorderWidth: 1,
            pointRadius: 3,
            fill: false,
            borderWidth: 4,
            data: [10,20,30,40,50,55,60,62,70,75,80,90,97]
        }]
    },
    options: {
        legend: {
            position: "bottom"
        },
        scales: {
            yAxes: [{
                ticks: {
                    fontColor: "rgba(0,0,0,0.5)",
                    fontStyle: "bold",
                    beginAtZero: true,
                    maxTicksLimit: 5,
                    padding: 20
                },
                gridLines: {
                    drawTicks: false,
                    display: false
                }

            }],
            xAxes: [{
                gridLines: {
                    zeroLineColor: "transparent"
                },
                ticks: {
                    padding: 20,
                    fontColor: "rgba(0,0,0,0.5)",
                    fontStyle: "bold"
                }
            }]
        }
    }
});


